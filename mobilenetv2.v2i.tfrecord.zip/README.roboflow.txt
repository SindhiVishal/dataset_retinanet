
mobilenetv2 - v2 2022-06-04 8:21pm
==============================

This dataset was exported via roboflow.ai on June 4, 2022 at 2:53 PM GMT

It includes 42 images.
Wheatheads are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise
* Salt and pepper noise was applied to 21 percent of pixels

The following transformations were applied to the bounding boxes of each image:
* Random Gaussian blur of between 0 and 10 pixels


